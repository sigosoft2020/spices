<footer class="footer text-right">
    © Copyright 2018 - <a href="www.woosloot.com" style="color:#69af8a;">www.wooslot.com</a>
</footer>
